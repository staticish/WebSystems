<?php
session_start();
 //Connects to the database
$conn = mysqli_connect("localhost", "c2229935_2229935", "2fD{l!@_pp%8", "c2229935_ish");
$query = "SELECT * FROM users";
$result = mysqli_query($conn, $query);

// Collects the username and password from the user if it exists
if (isset($_POST['username']) && isset($_POST['password'])) {
  $username = $_POST['username'];
  $password = $_POST['password'];
 
 $hash = "$2y$10$3sQxmgXGMjKhBashW3.GU.1pjBkI.Mv7ZxS.hp82fmq49Wy.0w24S";
$verifiedPass = password_verify($password, $hash);

  // Checks to see if the given input exists in database
  $query = "SELECT * FROM users WHERE username = '$username' AND password = '$hash'";
  $result = mysqli_query($conn, $query);
  
  if ($result) {
    // If a record is found
    if (mysqli_num_rows($result) === 1  && $verifiedPass) {
 
      // Grant administrative access

		$isAdminn = true;  

		// Store the admin status in a session variable that can be used accross pages
		$_SESSION['isAdminn'] = $isAdminn;
 
 // Redirect the user to the Review page :)
  
 header("Location: Review.php");
 
 exit;  
	 }
	else {
    
		echo "Invalid username or password. Please Try Again ";
	  }
  } 
  
  // Close the database connection
  mysqli_close($conn);
  
}
?>    
<!DOCTYPE html>
<html lang="en">
<head>
    <meta name = "description" content = "A simple login page that requests for username and password. If not available you can still continue as guest">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>J106387 Log-in page</title>
    <link type="text/css" rel="stylesheet" href="style.css">
</head>
  <body>
    <div class="loginDiv">
      <form method="POST" class="loginPart">
        <h2>Login to account</h2>
        <label for="username">Username</label>
        <input id = "username" type="text" autocomplete="off" placeholder="Enter Username" name="username" required>
        <label for="password">Password</label>
        <input id = "password" type="password" placeholder="Enter Password" name="password" required>
        <input style="cursor:pointer" type="submit" name="loginButton" value="Login">
        <br /> or <br /> 
        <?php echo '<a class = "guestButton" href="home.html">Continue as guest</a>'?>
      </form>
    </div>
  </body>
</html>