<?php
session_start();
    if (isset($_POST['logoutButton'])) {
        unset($_SESSION['isAdminn']);
        header("Location: index.php");
        exit();
    }
    ?> 
<!Doctype html>
<html lang="en">
<head>
     <meta name = "description" content = "A review page where being an admin is required before posting a review on your thoughts on harry potter">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>J106387 Review Page</title>
     <script src="index.js" defer></script>
    <link type="text/css" rel="stylesheet" href="style.css">
</head>
<body>


    <nav>
        <ul>
            <li><a href="home.html">Home</a></li>
            <li><a href="Characters.html">Characters</a></li>
            <li><a href="Review.php">Review</a></li>
            <li><a href="About.html">About</a></li>
        </ul>
    </nav>
 <div class = "reviewQuestion"><h1> Review</h1> 
    <h4> What are your thoughts on the Harry Potter franchise? </h4>
    </div> 
    <?php
   
     if (isset($_SESSION['isAdminn']) && $_SESSION['isAdminn']) {
 
    echo " <form method='POST' action='Review.php' class = 'nameAndText'>
    <input autocomplete = 'off' type='text' name='name' placeholder='Your Name' required>
    <textarea autocomplete = 'off' name='comment' placeholder='Your Comment' required></textarea>
    <button type='submit'>Submit</button>
</form>";
    $conn = mysqli_connect("localhost:3306", "c2229935_2229935", "2fD{l!@_pp%8", "c2229935_ish");
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
  
    if (isset($_POST['name']) && isset($_POST['comment'])) {
        $name = mysqli_real_escape_string($conn, $_POST['name']);
        $comment = mysqli_real_escape_string($conn, $_POST['comment']);
        $timestamp = $_POST['timestamp'];

        $sql = "INSERT INTO reviews (name, comment) VALUES ('$name', '$comment')";
        if ($conn->query($sql) === TRUE) {
            // Comment inserted successfully
            echo "Review posted!";
        } else {
          
            echo "Error: " . $conn->error;
        
           
        } 
       
    }
    $conn->close();

     }
     else{
echo "";
     }
   
    // If Admin exists and is true, then you are an admin and can see a logout button
    if (isset($_SESSION['isAdminn']) && $_SESSION['isAdminn']) {
        echo '<form method="post">
                <input name="logoutButton" class="logoutButton" type="submit" value="Logout">
              </form>';
    } else {
        echo '<div class="adminText">You are not an Admin. <button>
                  <a href="index.php">LOG IN</a>
              </button> to post a review</div>';
    }
    ?>
  
<div class="reviews">

<?php
$conn = mysqli_connect("localhost:3306", "c2229935_2229935", "2fD{l!@_pp%8", "c2229935_ish");
  $sql = "SELECT * FROM reviews ORDER BY id DESC";
    $result = $conn->query($sql);
//Code adapted from BraveCoderYT, n.d.
    if ($result->num_rows > 0) {
        // Output data of each row
        while ($row = $result->fetch_assoc()) {
?>
            <div class = "comments" style = "align-items: bottom">
            <svg class = "pfp" width="24" height="24" xmlns="http://www.w3.org/2000/svg" fill-rule="evenodd" clip-rule="evenodd"><path d="M12 0c6.623 0 12 5.377 12 12s-5.377 12-12 12-12-5.377-12-12 5.377-12 12-12zm8.127 19.41c-.282-.401-.772-.654-1.624-.85-3.848-.906-4.097-1.501-4.352-2.059-.259-.565-.19-1.23.205-1.977 1.726-3.257 2.09-6.024 1.027-7.79-.674-1.119-1.875-1.734-3.383-1.734-1.521 0-2.732.626-3.409 1.763-1.066 1.789-.693 4.544 1.049 7.757.402.742.476 1.406.22 1.974-.265.586-.611 1.19-4.365 2.066-.852.196-1.342.449-1.623.848 2.012 2.207 4.91 3.592 8.128 3.592s6.115-1.385 8.127-3.59zm.65-.782c1.395-1.844 2.223-4.14 2.223-6.628 0-6.071-4.929-11-11-11s-11 4.929-11 11c0 2.487.827 4.783 2.222 6.626.409-.452 1.049-.81 2.049-1.041 2.025-.462 3.376-.836 3.678-1.502.122-.272.061-.628-.188-1.087-1.917-3.535-2.282-6.641-1.03-8.745.853-1.431 2.408-2.251 4.269-2.251 1.845 0 3.391.808 4.24 2.218 1.251 2.079.896 5.195-1 8.774-.245.463-.304.821-.179 1.094.305.668 1.644 1.038 3.667 1.499 1 .23 1.64.59 2.049 1.043z"/></svg>
             <h5> <b> <?php echo $row['name']; ?>: &nbsp;&nbsp;&nbsp;  </b></h5>
            <h6 style="font-weight:100"><?php echo $row['comment']; ?></h6> <span style = "left: 90%;   position:absolute">
                <?php echo $row['timestamp']; ?></span></div>

<?php
//End of adapted code
        }
    }
  
?>

	</div>
</body>
<footer> BraveCoderYT. (n.d.). PHP-Comment-System. Retrieved 25th May From https://github.com/BraveCoderYT/PHP-Comment-System/blob/main/index.php</footer>
</html>
