let imageEl1 = document.getElementById("image1")
let imageEl2 = document.getElementById("image2")
let imageEl3 = document.getElementById("image3")
let mapEl = document.getElementById("mapel")
let mapCharEl = document.getElementById("mapChar")

function handleResponse(resp) {
    return resp.json()
}

const handleError = errorMsg => error => console.log(`${errorMsg}: ${error.message}`)

function fetchCharacters() {
    return fetch("https://hp-api.onrender.com/api/characters")
        .then(handleResponse)
        .catch(handleError("Error while fetching Characters"));

}


function fetchSpells() {
    return fetch("https://hp-api.onrender.com/api/spells").
    then(handleResponse)
    .catch(handleError("Error while fetching Spells"));            

}

function printRandomSpells() {
    let rand
    rand = Math.floor(Math.random() * 72) + 1

    printSpells(rand)
}

function printSpells(rand) {
    fetchSpells().then((resp) => {
        const firstFive = resp.slice(rand, rand + 5);

        const mapitems = firstFive.map((spell) => {
            return `<table><tr> <td> ${spell.name}</td> 
            <td> ${spell.description} </td></tr> </table>`

        })

        mapEl.innerHTML = mapitems.join('');

    })
}

function printCharacters() {
    return fetchCharacters().then((resp) => {

        imageEl1.src = resp[0].image
        imageEl2.src = resp[1].image
        imageEl3.src = resp[2].image
    })
}

function printAllCharacters() {
    fetchCharacters().then((resp) => {
        const charItems = resp.map(item => {
            return item.image ?
                `  <div class = "card"> <img src ="${item.image}" alt = '${item.name}' />
   <div class="info">
       <h5>  Name:   <span>${item.name} </span> </h5>
   <h5>  House:   <span> ${item.house} </span> </h5>
   <h5>  Date Of birth:  <span> ${item.dateOfBirth} </span></h5>
   <h5>  Gender: <span>  ${item.gender} </span> </h5>
   <h5>  Ancestry: <span> ${item.ancestry} </span> </h5>
   <h5>  Actor:  <span> ${item.actor} </span> </h5>
   </div>
   </div>
    ` : ""
        })

        return mapCharEl.innerHTML = charItems.join('')
    })

}

printAllCharacters()
printCharacters()
printRandomSpells()